<h1 align="center">🚀 LoveTool 🚀</h1>
<em><h5 align="center">(Language: Python, Shell)</h5></em>
  
<p align="center">Vui lòng không tấn công các trang web liên quan tới chính phủ.</p>

<p align="center"><img src="https://i.imgur.com/slbFTPZ.jpeg" width="600" height="200" alt="Script"></p>
<p align="center"><img src="https://i.imgur.com/ZFPU2zj.png" width="800" height="500" alt="Demo DDoS"></p>

# Mothed

* SOCKET FLOOD
* GET FLOOD
* BYPASS

# Cách Setup

* Vào CH Play Hoặc Appstore Tải Google Cloud Để Chạy Tool Nhé!

* ```git clone https://github.com/ViDucHung206/LoveTool```
* ```cd LoveTool```
* ```sh setup.sh```
* ```python abc.py```

# Cách Vào Tool

* ```cd LoveTool```
* ```python abc.py```

# Contact Me 
* Telegram: @hungtricker
* Zalo: 0359822840
* Facebook: @Users.ViDucHung.ProFile

# Donate 
* Momo: 0359822840 <br>
CTK: Vi Đức Hùng 
* Tsr: 0359822840 <br>
CTK: Vi Hùng
* MBBank: 88888888190506 <br>
CTK: Long Thi Dong 

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/ViDucHung206/LoveToolhit-counter&count_bg=%230BD4FF&title_bg=%23525050&icon=github.svg&icon_color=%23000000&title=Views&edge_flat=true)](https://hits.seeyoufarm.com)




